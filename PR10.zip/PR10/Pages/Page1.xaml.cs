﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace PR10.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }
        private void btnListFromFile_Click(object sender, RoutedEventArgs e)
        {
            lstInput.Items.Clear();
            StreamReader sr = new StreamReader(@"input.txt", Encoding.UTF8);
            while (!sr.EndOfStream)
            {
                lstInput.Items.Add(sr.ReadLine());
            }
        }
        private void btnResult_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int index = lstInput.SelectedIndex;
                string str = (string)lstInput.Items[index];
                string[] arr = str.Split(' ');
                string result = "";
                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i].Length != 1)
                    {
                        char ch1 = arr[i][0];
                        char ch2 = arr[i][arr[i].Length - 1];
                        arr[i] = ch2 + arr[i].Substring(1, arr[i].Length - 2) + ch1;
                    }
                    result += arr[i] + " ";
                }
                lstInput2.Text = result;
            }
            catch (Exception)
            {
                StreamWriter sw = new StreamWriter(@"Result.txt", true, Encoding.UTF8);
                sw.Close();
            }
        }
        private void btnClearAll_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter sw = new StreamWriter(@"Result.txt", false, Encoding.UTF8);
            sw.Write("");
            sw.Close();
            txbResult.Text = "";
            lstInput2.Text = "";
            lstInput.Items.Clear();
        }
    }
}
